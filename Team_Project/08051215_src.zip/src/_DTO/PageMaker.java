package _DTO;

public class PageMaker {
	private int pageSize = 9; // how many read board in page
	private int startPage; //start of block
	private int endPage; // end of block
	private int curPage = 1;
	private int start; // start of page
	private int totalCount; // All record count
	private boolean next;	// next  page
	private boolean prev; // prev page 
	
	public PageMaker(int curPage, int totalCount) {
		this.curPage=curPage;
		this.totalCount = totalCount;
		start=(curPage-1)*pageSize;
		int totalPage = (int)(Math.ceil(totalCount/(double)pageSize));
		
		prev = curPage == 1 ? false : true;
		next = curPage >= totalPage ? false : true;  
	}

	public int getPageSize() {
		return pageSize;
	}

	public int getStartPage() {
		return startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public int getCurPage() {
		return curPage;
	}

	public int getStart() {
		return start;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public boolean isNext() {
		return next;
	}

	public boolean isPrev() {
		return prev;
	}
	
}
